/** \defgroup scalar
 *  \brief Scalar operations
 */

/** \defgroup vector
 *  \brief Vector operations (relating to the class cotila::vector)
 */

/** \defgroup matrix
 *  \brief Matrix operations (relating to the class cotila::matrix)
 */
