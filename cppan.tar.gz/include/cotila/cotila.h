#ifndef COTILA_COTILA_H_
#define COTILA_COTILA_H_

#include <cotila/matrix/math.h>
#include <cotila/matrix/matrix.h>
#include <cotila/matrix/operators.h>
#include <cotila/matrix/utility.h>
#include <cotila/scalar/math.h>
#include <cotila/vector/math.h>
#include <cotila/vector/operators.h>
#include <cotila/vector/utility.h>
#include <cotila/vector/vector.h>

#endif // COTILA_COTILA_H_
